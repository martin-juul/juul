import { Component } from 'solid-js';

export default () => {
  return (
    <>
      <p class="text-4xl text-red-400 tracking-widest">Projects component</p>
    </>
  );
}
